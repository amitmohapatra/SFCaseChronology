function loadHistoryTable(json_string_data) {

	// variable defined
	var jsonDate = $.parseJSON(json_string_data);
	var sortedDateArray = Object.keys(jsonDate).sort(function(a, b) {
		return Date.parse(a) < Date.parse(b) ? 1 : -1;
	});
	var caseHistoryTableHeader = [ 'Date/Time', 'Created By', 'Modified By',
			'Assigned To', 'Customer', 'Type', 'Summary', 'Details',
			'Case Actions', 'Priority', 'Status' ];
	var tableString = '';
	var typeElement = '';

	function createTableTr(trArray) {
		var txt = '<tr>';
		jQuery.each(trArray, function(i, val) {
			txt = txt + '<td>' + val + '</td>';
		});
		txt = txt + '</tr>';
		return txt;
	}

	function createTable() {

		var txt = '<tr>';
		jQuery.each(caseHistoryTableHeader, function(i, val) {
			txt = txt + '<th>' + val + '</th>';
		});
		txt = txt + '</tr>';
		tableString = txt + tableString;
		$("#largeTable").html(tableString);
	}

	function prepareTooltipTable(elementKey, tooltipHeade, elementObject) {
		var customTooltipTable = '<table class=customTable>';
		$
				.each(
						elementKey,
						function(k, v) {
							var val = elementObject[v];

							if (val != 'NA') {
								var header = tooltipHeade[k];
								if (val === 'false'
										&& (v === 'Deleted' || v === 'Private'
												|| v === 'Published' || v === 'Closed')) {
									val = 'No';
								}
								if (val === 'true'
										&& (v === 'Deleted' || v === 'Private'
												|| v === 'Published' || v === 'Closed')) {
									val = 'Yes';
								}

								if (v === 'AttachmentLink') {
									var aVal = String
											.format(
													'<a href=/servlet/servlet.FileDownload?file={0} target=_blank >View</a>',
													val);
									customTooltipTable = customTooltipTable
											+ '<tr><td>' + header
											+ ' : </td><td>' + aVal
											+ '</td></tr>';
								} else if (v == 'Attachment') {
									customTooltipTable = customTooltipTable
											+ '<tr><td>' + header
											+ ' : </td><td>' + val
											+ '</td></tr>';
								} else {
									customTooltipTable = customTooltipTable
											+ '<tr><td>' + header
											+ ' : </td><td><b>' + val
											+ '</b></td></tr>';
								}
							}
						});
		
		customTooltipTable = customTooltipTable + '</table>';
		return customTooltipTable;
	}

	function innerTooltipTable(elementObject) {
		var customTooltipTable = '<table>';

		var nameTd = '<tr><td>Name : </td>';
		var LinkTd = '<tr><td>Link : </td>';
		$
				.each(
						$.parseJSON(elementObject),
						function(key, value) {
							$
									.each(
											value,
											function(k, v) {
												v = v.replace(/"/g, "'");
												if (k == 'Name') {
													nameTd = nameTd + '<td><b>'
															+ v + '</b></td>';
												}

												if (k == 'Id') {
													LinkTd = LinkTd
															+ String
																	.format(
																			'<td><a href=/servlet/servlet.FileDownload?file={0} target=_blank><b>View</b></a></td>',
																			v);
												}

											});
						});
		nameTd = nameTd + '</tr>';
		LinkTd = LinkTd + '</tr>';
		customTooltipTable = customTooltipTable + nameTd + LinkTd;
		customTooltipTable = customTooltipTable + '</table>';
		return customTooltipTable;

	}

	function linkToPage(relativeUrl, name) {
		return String.format('<a href="/{0}" target="_blank" >{1}</a>',
				relativeUrl, name);
	}

	function linkViewPage(relativeUrl, tooltipStr, name) {
		return String
				.format(
						'<a href="/{0}" title="{1}" target="_blank" class="customTooltip">{2}</a>',
						relativeUrl, tooltipStr, name);
	}

	function popUpTooltip(tooltipStr, name, hasAttachment) {
		if (hasAttachment) {
			return String
					.format(
							'<a href="#" title="{0}" target="_blank" class="customTooltipAttachment">{1}</a>',
							tooltipStr, name);
		} else {
			return String
					.format(
							'<a href="#" title="{0}" target="_blank" class="customTooltip">{1}</a>',
							tooltipStr, name);
		}
	}

	function prepareCaseHistoryTable(tableTRArray, elementObject) {
		if (elementObject.hasOwnProperty("CreatedById")) {
			var elementKey = [ 'CreatedByName', 'CreatedByEmail',
					'CreatedByMobilePhone', 'CreatedByPhone', 'CreatedDate' ];
			var tooltipHeader = [ 'Name', 'Email', 'Mobile', 'Phone',
					'Created Date' ];
			var toltipStr = prepareTooltipTable(elementKey, tooltipHeader,
					elementObject);
			var hyperLink = linkViewPage(elementObject["CreatedById"],
					toltipStr, elementObject["CreatedByName"]);
			tableTRArray.splice(1, 1, hyperLink);
		} else {
			tableTRArray.splice(1, 1, 'NA');
		}

		if (elementObject.hasOwnProperty("ModifiedById")) {
			var elementKey = [ 'ModifiedByName', 'ModifiedByEmail',
					'ModifiedByMobilePhone', 'ModifiedByPhone',
					'LastModifiedDate' ];
			var tooltipHeader = [ 'Name', 'Email', 'Mobile', 'Phone',
					'Modified Date' ];
			var toltipStr = prepareTooltipTable(elementKey, tooltipHeader,
					elementObject);
			var hyperLink = linkViewPage(elementObject["ModifiedById"],
					toltipStr, elementObject["ModifiedByName"]);
			tableTRArray.splice(2, 1, hyperLink);
		} else {
			tableTRArray.splice(2, 1, 'NA');
		}

		if (elementObject.hasOwnProperty("OwnerId")) {
			var elementKey = [ 'OwnerName', 'OwnerEmail', 'OwnerMobilePhone',
					'OwnerPhone' ];
			var tooltipHeader = [ 'Name', 'Email', 'Mobile', 'Phone' ];
			var toltipStr = prepareTooltipTable(elementKey, tooltipHeader,
					elementObject);
			var hyperLink = linkViewPage(elementObject["OwnerId"], toltipStr,
					elementObject["OwnerName"]);
			tableTRArray.splice(3, 1, hyperLink);
		} else {
			tableTRArray.splice(3, 1, 'NA');
		}

		if (elementObject.hasOwnProperty("CustomerId")) {
			var elementKey = [ 'CustomerName', 'CustomerEmail',
					'CustomerMobilePhone', 'CustomerPhone' ];
			var tooltipHeader = [ 'Name', 'Email', 'Mobile', 'Phone' ];
			var toltipStr = prepareTooltipTable(elementKey, tooltipHeader,
					elementObject);
			var hyperLink = linkViewPage(elementObject["CustomerId"],
					toltipStr, elementObject["CustomerName"]);
			tableTRArray.splice(4, 1, hyperLink);
		} else {
			tableTRArray.splice(4, 1, 'NA');
		}

		tableTRArray.splice(5, 1, elementObject['Element']);

		var elemType = elementObject['Element'].toLowerCase();

		if (elemType === 'histories') {
			tableTRArray.splice(6, 1, elementObject['NewValue']);
			var elementKey = [ 'NewValue', 'OldValue', "Field", "CreatedDate",
					'Deleted' ];
			var tooltipHeader = [ 'New Value', 'Old Value',
					'Case Field Modified', 'Created Date', 'Deleted' ];
			var toltipStr = prepareTooltipTable(elementKey, tooltipHeader,
					elementObject);
			var blankHyperLink = popUpTooltip(toltipStr, 'History Details',
					false);
			tableTRArray.splice(7, 1, blankHyperLink);
			tableTRArray.splice(8, 1, 'NA');
			tableTRArray.splice(9, 1, 'NA');

			var isDeleted = elementObject['Deleted'].toLowerCase();
			if (isDeleted === 'true') {
				tableTRArray.splice(10, 1, 'Deleted');
			} else {
				tableTRArray.splice(10, 1, 'Active');
			}
		} else if (elemType === 'casesolutions') {
			tableTRArray.splice(6, 1, elementObject['SolutionId']);
			var elementKey = [ 'SolutionId', 'CreatedDate', 'Deleted' ];
			var tooltipHeader = [ 'Solution Id', 'Created Date', 'Deleted' ];
			var toltipStr = prepareTooltipTable(elementKey, tooltipHeader,
					elementObject);
			var blankHyperLink = popUpTooltip(toltipStr,
					'CaseSolution Details', false);
			tableTRArray.splice(7, 1, blankHyperLink);
			tableTRArray.splice(8, 1, 'NA');
			tableTRArray.splice(9, 1, 'NA');

			var isDeleted = elementObject['Deleted'].toLowerCase();
			if (isDeleted === 'true') {
				tableTRArray.splice(10, 1, 'Deleted');
			} else {
				tableTRArray.splice(10, 1, 'Active');
			}
		} else if (elemType === 'casecomments') {
			tableTRArray.splice(6, 1, elementObject['CommentBody']);
			var elementKey = [ 'CommentBody', 'LastModifiedDate', 'Deleted',
					'Published' ];
			var tooltipHeader = [ 'Comment Body', 'Modified Date', 'Deleted',
					'Published' ];
			var toltipStr = prepareTooltipTable(elementKey, tooltipHeader,
					elementObject);
			var blankHyperLink = popUpTooltip(toltipStr, 'CaseComment Details');
			tableTRArray.splice(7, 1, blankHyperLink);

			var pUrl = elementObject['Id'] + '/e?parent_id='
					+ elementObject['ParentId'];
			var editPage = linkToPage(pUrl, 'Edit', false)
			tableTRArray.splice(8, 1, editPage);

			tableTRArray.splice(9, 1, 'NA');

			var isDeleted = elementObject['Deleted'].toLowerCase();
			if (isDeleted === 'true') {
				tableTRArray.splice(10, 1, 'Deleted');
			} else {
				var isPublished = elementObject['Published'].toLowerCase();
				if (isPublished === "true") {
					tableTRArray.splice(10, 1, 'Public');
				} else {
					tableTRArray.splice(10, 1, 'Private');
				}
			}
		} else if (elemType === 'attachments') {
			tableTRArray.splice(6, 1, elementObject['Name']);
			var elementKey = [ 'Name', 'Description', 'AttachmentLink',
					'CreatedDate', 'LastModifiedDate', 'Deleted', 'Private' ];
			var tooltipHeader = [ 'Name', 'Description', 'Link',
					'Created Date', 'Modified Date', 'Deleted', 'Private' ];
			var toltipStr = prepareTooltipTable(elementKey, tooltipHeader,
					elementObject);
			var blankHyperLink = popUpTooltip(toltipStr, 'Attachments Details',
					true);
			tableTRArray.splice(7, 1, blankHyperLink);

			var vUrl = linkToPage(elementObject['Id'], 'view');
			var eUrl = linkToPage(elementObject['Id'] + '/e', 'Edit');
			var dUrl = linkToPage(elementObject['Id'] + '/d', 'Delete');
			tableTRArray.splice(8, 1, vUrl + ' / ' + eUrl + ' / ' + dUrl);

			tableTRArray.splice(9, 1, 'NA');

			var isDeleted = elementObject['Deleted'].toLowerCase();
			if (isDeleted === 'true') {
				tableTRArray.splice(10, 1, 'Deleted');
			} else {
				var isPrivate = elementObject['Private'].toLowerCase();
				if (isPrivate === "true") {
					tableTRArray.splice(10, 1, 'Private');
				} else {
					tableTRArray.splice(10, 1, 'Public');
				}
			}
		} else {

			if (elementObject['Element'] === 'Task'
					|| elementObject['Element'] === 'Event') {
				tableTRArray.splice(5, 1, elementObject['Element'] + ' : '
						+ elementObject['Subject']);
			} else {
				tableTRArray.splice(5, 1, elementObject['Element']);
			}

			if (elementObject['Element'] === 'Email') {
				var sub = elementObject['Subject'];
				var sub = sub.substring(sub.indexOf(" ") + 1, sub.length);
				tableTRArray.splice(6, 1, sub);
			} else {
				tableTRArray.splice(6, 1, elementObject['Description']);
			}

			tableTRArray.splice(9, 1, elementObject['Priority']);
			tableTRArray.splice(10, 1, elementObject['Status']);

			var vUrl = linkToPage(elementObject['Id'], 'view');
			var eUrl = linkToPage(elementObject['Id'] + '/e', 'Edit');
			var dUrl = linkToPage(elementObject['Id'] + '/d', 'Delete');
			tableTRArray.splice(8, 1, vUrl + ' / ' + eUrl + ' / ' + dUrl);

			var elementKey = [ 'Subject', 'Description', 'CreatedDate',
					'LastModifiedDate', 'ActivityDate', 'Priority', 'Status',
					'Closed' ];
			var tooltipHeader = [ 'Subject', 'Description', 'Created Date',
					'Modified Date', 'Due Date', 'Priority', 'Status', 'Closed' ];

			var delay = false;

			if (elementObject['AttachmentLink'] != 'NA') {
				var attachmentTable = innerTooltipTable(elementObject['AttachmentLink']);
				elementKey.push('Attachment');
				tooltipHeader.push('Attachment');
				delete elementObject['AttachmentLink'];
				elementObject['Attachment'] = attachmentTable;
				delay = true;
			}

			var toltipStr = prepareTooltipTable(elementKey, tooltipHeader,
					elementObject);
			var blankHyperLink = popUpTooltip(toltipStr,
					elementObject['Element'] + ' Details', delay);
			tableTRArray.splice(7, 1, blankHyperLink);
		} 
	}

	var count = 0;
	$.each(sortedDateArray, function(k, v) {
		if (v != null) {
			v = v.trim();
			if (v) {
				var tableTRArray = [ v, '', '', '', '', '', '', '', '', '' ];
				var elementObject = jsonDate[v];
				prepareCaseHistoryTable(tableTRArray, elementObject);
				tableString = tableString + createTableTr(tableTRArray);
			}
		}
	});

	createTable();

}