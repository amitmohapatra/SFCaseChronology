$(document).ready(function() {

    // String format function.
	String.format = function() {
		var theString = arguments[0];

		for (var i = 1; i < arguments.length; i++) {
			var regEx = new RegExp("\\{" + (i - 1) + "\\}", "gm");
			theString = theString.replace(regEx, arguments[i]);
		}
		return theString;
	}

	$(function() {
		$('.customTooltip').tooltip({
			html : true,
			delay : {
				show : 0,
				hide : 0
			},
			trigger : 'hover',
			placement : function(tip, element) {
				var position = $(element).position();

				if (position.left > 515) {
					return "left";
				}
				if (position.left < 515) {
					return "right";
				}
				if (position.top < 110) {
					return "bottom";
				}
				return "top";
			}
		});
	});
	
	// if any attachment link present in tooltip table
	// then apply delay.

	$(function() {
		$('.customTooltipAttachment').tooltip({
			html : true,
			delay : {
				show : 0,
				hide : 3000
			},
			trigger : 'hover',
			placement : function(tip, element) {
				var position = $(element).position();
				if (position.left > 515) {
					return "left";
				}
				if (position.left < 515) {
					return "right";
				}
				if (position.top < 110) {
					return "bottom";
				}
				return "top";
			}
		});
	});
});