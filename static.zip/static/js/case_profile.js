function loadCaseProfileTable(caseProfileJson) {
	// json parse to make object
	var jsoncaseProfile = $.parseJSON(caseProfileJson);

	// This function helps to generate html table string
	// html string are put into array fo <td> sequence can esily change.
	function prepareCaseProfileTable(caseId, elementObject) {

		var tBody = [];
		
		// *****************************************CaseNumber*************************************************************************
		if (elementObject['CaseNumber'] != 'NA') {
			var caseNum = '<a href=/' + caseId + ' target=_blank><b>'
					+ elementObject['CaseNumber'] + '</b></a>';
			tBody
					.push('<td id=left_side_col>Case Number : </td><td id=right_side_col><b>'
							+ caseNum + '</b></td>');
		}

		// *****************************************OwnerName**************************************************************************
		if (elementObject['OwnerName'] != 'NA') {
			var ownerTr = '';
			if (elementObject['OwnerEmail'] != 'NA') {
				ownerTr = ownerTr + '<tr><td>Email : </td><td>'
						+ elementObject['OwnerEmail'] + '</td></tr>';
			}
			if (elementObject['OwnerMobilePhone'] != 'NA') {
				ownerTr = ownerTr + '<tr><td>Mobile : </td><td>'
						+ elementObject['OwnerMobilePhone'] + '</td></tr>';
			}
			if (elementObject['OwnerPhone'] != 'NA') {
				ownerTr = ownerTr + '<tr><td>Phone : </td><td>'
						+ elementObject['OwnerPhone'] + '</td></tr>';
			}

			var tooltipStr = '<table class=customTable>' + ownerTr + '</table>';
			var caseNum = String
					.format(
							'<a href="/{0}" title="{1}" target="_blank" class="customTooltip">{2}</a>',
							elementObject['OwnerId'], tooltipStr,
							elementObject['OwnerName']);
			tBody
					.push('<td id=left_side_col>Case Owner : </td><td id=right_side_col><b>'
							+ caseNum + '</b></td>');
		}

		// *****************************************Status*****************************************************************************
		if (elementObject['Status'] != 'NA') {
			tBody
					.push('<td id=left_side_col>Status : </td><td id=right_side_col><b>'
							+ elementObject['Status'] + '</b></td>');
		}
		
		// *****************************************AccountName*************************************************************************
		if (elementObject['AccountName'] != 'NA') {
			var accNum = '<a href=/' + elementObject['AccountId']
					+ ' target=_blank><b>' + elementObject['AccountName']
					+ '</b></a>';
			tBody
					.push('<td id=left_side_col>Account Name : </td><td id=right_side_col><b>'
							+ accNum + '</b></td>');
		}

		// *****************************************OwnerRole**************************************************************************
		tBody
				.push('<td id=left_side_col>Case Owner Role : </td><td id=right_side_col><b>'
						+ elementObject['OwnerRole'] + '</b></td>');
		
		// *****************************************Priority***************************************************************************
		tBody
				.push('<td id=left_side_col>Priority : </td><td id=right_side_col><b>'
						+ elementObject['Priority'] + '</b></td>');
	    
		// *****************************************Subject****************************************************************************
		tBody
				.push('<td id=left_side_col>Subject : </td><td id=right_side_col><b>'
						+ elementObject['Subject'] + '</b></td>');

	    // *****************************************ContactName************************************************************************
		if (elementObject['ContactName'] != 'NA') {
			var contactTr = '';
			if (elementObject['ContactEmail'] != 'NA') {
				contactTr = contactTr + '<tr><td>Email : </td><td>'
						+ elementObject['ContactEmail'] + '</td></tr>';
			}
			if (elementObject['ContactMobilePhone'] != 'NA') {
				contactTr = contactTr + '<tr><td>Mobile : </td><td>'
						+ elementObject['ContactMobilePhone'] + '</td></tr>';
			}
			if (elementObject['ContactPhone'] != 'NA') {
				contactTr = contactTr + '<tr><td>Phone : </td><td>'
						+ elementObject['ContactPhone'] + '</td></tr>';
			}

			var tooltipStr = '<table class=customTable>' + contactTr
					+ '</table>';
			var caseNum = String
					.format(
							'<a href="/{0}" title="{1}" target="_blank" class="customTooltip">{2}</a>',
							elementObject['ContactId'], tooltipStr,
							elementObject['ContactName']);

			tBody
					.push('<td id=left_side_col>Contact Name : </td><td id=right_side_col><b>'
							+ caseNum + '</b></td>');
		}

		// *****************************************Case Origin***********************************************************************
		tBody
				.push('<td id=left_side_col>Case Origin : </td><td id=right_side_col><b>'
						+ elementObject['Origin'] + '</b></td>');
		
		// *****************************************Description***********************************************************************
		tBody
				.push('<td id=left_side_col>Description : </td><td id=right_side_col><b>'
						+ elementObject['Description'] + '</b></td>');
		
		// *****************************************Contact Id************************************************************************
		tBody
				.push('<td id=left_side_col>Contact Id : </td><td id=right_side_col><b>'
						+ elementObject['ContactId'] + '</b></td>');

		// *****************************************Closed****************************************************************************
		if (elementObject['Closed'] != 'NA') {
			if (elementObject['Closed'] == 'true') {
				tBody
						.push('<td id=left_side_col>Closed : </td><td id=right_side_col><b>Yes</b></td>');
			} else {
				tBody
						.push('<td id=left_side_col>Closed : </td><td id=right_side_col><b>No</b></td>');
			}
		}
		
		// *****************************************Case Reason***********************************************************************
		tBody
				.push('<td id=left_side_col>Case Reason : </td><td id=right_side_col><b>'
						+ elementObject['Reason'] + '</b></td>');

		// *****************************************CreatedByName*********************************************************************
		if (elementObject['CreatedByName'] != 'NA') {
			var createdByTr = '';
			if (elementObject['CreatedByEmail'] != 'NA') {
				createdByTr = createdByTr + '<tr><td>Email : </td><td>'
						+ elementObject['CreatedByEmail'] + '</td></tr>';
			}
			if (elementObject['CreatedByMobilePhone'] != 'NA') {
				createdByTr = createdByTr + '<tr><td>Mobile : </td><td>'
						+ elementObject['CreatedByMobilePhone'] + '</td></tr>';
			}
			if (elementObject['CreatedByPhone'] != 'NA') {
				createdByTr = createdByTr + '<tr><td>Phone : </td><td>'
						+ elementObject['CreatedByPhone'] + '</td></tr>';
			}

			var tooltipStr = '<table class=customTable>' + createdByTr
					+ '</table>';
			var caseNum = String
					.format(
							'<a href="/{0}" title="{1}" target="_blank" class="customTooltip">{2}</a>',
							elementObject['CreatedById'], tooltipStr,
							elementObject['CreatedByName']);
			tBody
					.push('<td id=left_side_col>Created By : </td><td id=right_side_col><b>'
							+ caseNum + '</b></td>');
		}
        
		// *****************************************Deleted**************************************************************************
		if (elementObject['Deleted'] != 'NA') {
			if (elementObject['Deleted'] == 'true') {
				tBody
						.push('<td id=left_side_col>Deleted : </td><td id=right_side_col><b>Yes</b></td>');
			} else {
				tBody
						.push('<td id=left_side_col>Deleted : </td><td id=right_side_col><b>No</b></td>');
			}
		}
		
		// *****************************************Billing Country******************************************************************
		tBody
				.push('<td id=left_side_col>Billing Country : </td><td id=right_side_col><b>'
						+ elementObject['BillingCountry'] + '</b></td>');

		// *****************************************ModifiedByName*******************************************************************
		if (elementObject['ModifiedByName'] != 'NA') {
			var modifiedByTr = '';
			if (elementObject['ModifiedByEmail'] != 'NA') {
				modifiedByTr = modifiedByTr + '<tr><td>Email : </td><td>'
						+ elementObject['ModifiedByEmail'] + '</td></tr>';
			}
			if (elementObject['ModifiedByMobilePhone'] != 'NA') {
				modifiedByTr = modifiedByTr + '<tr><td>Mobile : </td><td>'
						+ elementObject['ModifiedByMobilePhone'] + '</td></tr>';
			}
			if (elementObject['ModifiedByPhone'] != 'NA') {
				modifiedByTr = modifiedByTr + '<tr><td>Phone : </td><td>'
						+ elementObject['ModifiedByPhone'] + '</td></tr>';
			}

			var tooltipStr = '<table class=customTable>' + createdByTr
					+ '</table>';
			var caseNum = String
					.format(
							'<a href="/{0}" title="{1}" target="_blank" class="customTooltip">{2}</a>',
							elementObject['ModifiedById'], tooltipStr,
							elementObject['ModifiedByName']);
			tBody
					.push('<td id=left_side_col>Modified By : </td><td id=right_side_col><b>'
							+ caseNum + '</b></td>');
		}

		// *****************************************Escalated***********************************************************************
		if (elementObject['Escalated'] != 'NA') {
			if (elementObject['Escalated'] == 'true') {
				tBody
						.push('<td id=left_side_col>Escalated : </td><td><b>Yes</b></td>');
			} else {
				tBody
						.push('<td id=left_side_col>Escalated : </td><td id=right_side_col><b>No</b></td>');
			}
		}
		
		// *****************************************Case Type************************************************************************
		tBody
				.push('<td id=left_side_col>Case Type : </td><td id=right_side_col><b>'
						+ elementObject['Type'] + '</b></td>');
		
		// *****************************************Date/Time Created Date***********************************************************
		tBody
				.push('<td id=left_side_col>Date/Time Created Date : </td><td id=right_side_col><b>'
						+ elementObject['CreatedDate'] + '</b></td>');
						
		// *****************************************Engineering Req Number***********************************************************
		tBody
				.push('<td id=left_side_col>Engineering Req Number : </td><td id=right_side_col><b>'
						+ elementObject['EngineeringReqNumber'] + '</b></td>');
					
        // *****************************************Product**************************************************************************				
		tBody
				.push('<td id=left_side_col>Product : </td><td id=right_side_col><b>'
						+ elementObject['Product'] + '</b></td>');
		
		// *****************************************SLA Violation********************************************************************
		tBody
				.push('<td id=left_side_col>SLA Violation : </td><td id=right_side_col><b>'
						+ elementObject['SLAViolation'] + '</b></td>');
		
		// *****************************************Potential Liability**************************************************************
		tBody
				.push('<td id=left_side_col>Potential Liability : </td><td id=right_side_col><b>'
						+ elementObject['PotentialLiability'] + '</b></td>');
						
	    // *****************************************Date/Time Last Modified Date*****************************************************
		tBody
				.push('<td id=left_side_col>Date/Time Last Modified Date : </td><td id=right_side_col><b>'
						+ elementObject['LastModifiedDate'] + '</b></td>');
		
		// *****************************************Date of last comment*************************************************************
		tBody
				.push('<td id=left_side_col>Date of last comment : </td><td id=right_side_col><b>'
						+ elementObject['CaseCommentsLastModifiedDate']
						+ '</b></td>');
						
		// *****************************************First Public comment added Date**************************************************
		tBody
				.push('<td id=left_side_col>First Public comment added Date : </td><td id=right_side_col><b>'
						+ elementObject['CaseCommentsCreatedDate']
						+ '</b></td>');
						
	    // *****************************************Date/Time Closed*****************************************************************
		tBody
				.push('<td id=left_side_col>Date/Time Closed : </td><td id=right_side_col><b>'
						+ elementObject['ClosedDate'] + '</b></td>');
						
		// *****************************************Parent Case Number***************************************************************
		tBody
				.push('<td id=left_side_col>Parent Case Number: </td><td id=right_side_col><b>'
						+ elementObject['ParentCaseNumber'] + '</b></td>');
	    
        // **************************************************************************************************************************	
        // add a blank td if needed
		// devide table to 3 uniform column
		var count = 0;
		var bodyTr = '';
		var finalTr = '';
		$.each(tBody, function(i, v) {
			count = count + 1;
			bodyTr = bodyTr + v;
			if (count == 3) {
				finalTr = finalTr + '<tr>' + bodyTr + '</tr>';
				bodyTr = '';
				count = 0;
			}
		});

		if (count > 0) {
			if (count == 1) {
				bodyTr = bodyTr + '<td></td><td></td><td></td><td></td>';
			} else {
				bodyTr = bodyTr + '<td></td><td></td>';
			}
			finalTr = finalTr + '<tr>' + bodyTr + '</tr>';
		}
		// *************************************************************************************************************************
		return finalTr;
	}

	// iterate over object
	$.each(jsoncaseProfile, function(k, v) {

		if (k != null) {
			k = k.trim();

			if (k) {
				var elementObject = jsoncaseProfile[k];
				var tableHtml = prepareCaseProfileTable(k, elementObject);
				$('#caseProfileTable').html(tableHtml);
			}
		}
	});

}